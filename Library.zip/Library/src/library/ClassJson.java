/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

/**
 *
 * @author Miky
 */
public class ClassJson {
    
   
    public ClassJson(){}
    
    private String LeggiContenuto(URL url) throws IOException
    {
        String inline = "";
        Scanner scanner = new Scanner(url.openStream());
  
        //Write all the JSON data into a string using a scanner
        while (scanner.hasNext()) {
           inline += scanner.nextLine();
        }
        //Close the scanner
        scanner.close();
        return inline;
    }
    
    /*nelle classi passo il json object e parlo direttamente i parametri
    JSONObject obj = new JSONObject(inline); //parsare il documento iniziale in JSONObject
    JSONObject res = (JSONObject) obj.get("result"); //prendo l'object JSON result
    String message_id = res.get("message_id").toString(); //prendo il valore della chiave tra parentesi 
    JSONArray res = (JSONArray) obj.get("result"); //prendo il vettore result*/
}
