/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Miky
 */
public class ClassCsv {
    
    public ClassCsv(){}
    
    //salvo su csv
    public void SaveCsv(File f, List<String> dati)
    {
        FileWriter fw;
        BufferedWriter bf;
        try {
            fw = new FileWriter(f);
            bf = new BufferedWriter(fw); 
            bf.write("ciao"); //esempio
            
            bf.flush();
            bf.close();
        } catch (IOException ex) {
            Logger.getLogger(ClassCsv.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //leggo da file
    public void ReadCsv(File f)
    {
        List<String> lista = new ArrayList<>();
        FileReader fr;
        try {
            fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            while(linea != null)                                                                        
            {
                String[] d = linea.split(";"); //vettore con dentro le informazioni splittate
                lista.add(d[1]); //esempio
                linea = br.readLine();
            };
        } catch (IOException ex) {
            Logger.getLogger(ClassCsv.class.getName()).log(Level.SEVERE, null, ex);
        }
        return;
    }
}
