/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import static java.lang.System.in;
import java.net.URL;
import java.util.stream.Collectors;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/**
 *
 * @author Miky
 */
public class ClassXml {
    
    Document document;
    DocumentBuilderFactory factory;
    DocumentBuilder builder;
    Element root, element;
    
    public ClassXml(){}
    
    //prendo la root
    public Element GetRoot(String url) throws ParserConfigurationException, SAXException, IOException
    {
        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        
        document = builder.parse(url);
        root = document.getDocumentElement();
        return root;
        
        /*
        Element element = (Element) root.getElementsByTagName("place").item(0); //prendo il primo tag
        element.getElementsByTagName("town").item(0).getTextContent(); //del tag sopra prendo il figlio <town>
        element.getAttribute("lat"); //prendo l'attributo di un tag
        
        Float.parseFloat() --> parsare da stringa a float
        Integer.parseInt() --> parsare da stringa a int
        Float.toString() --> parsare da float a string
        String.valueOf() --> parsare da integer a string
        
        String value = URLEncoder.encode(valore, StandardCharsets.UTF_8.toString()) --> url encoding*/
    }
}
